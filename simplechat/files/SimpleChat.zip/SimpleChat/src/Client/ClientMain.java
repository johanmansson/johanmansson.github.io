package Client;

/**
 * Created by johanmansson on 15-04-27.
 */
public class ClientMain {

    public static void main(String[] args) {

        ClientHandler client = new ClientHandler();
        StartWindow window = new StartWindow(client);









    }

}
